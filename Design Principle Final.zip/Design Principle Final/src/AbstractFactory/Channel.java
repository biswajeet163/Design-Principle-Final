package AbstractFactory;

public abstract class Channel {
}
